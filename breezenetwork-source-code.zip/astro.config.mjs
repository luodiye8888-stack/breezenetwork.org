import { defineConfig } from 'astro/config';
import tailwind from '@astrojs/tailwind';
import sitemap from '@astrojs/sitemap';

export default defineConfig({
  site: 'https://breezenetwork.org',
  integrations: [
    tailwind(),
    sitemap({
      filter: (page) => !page.includes('/go') && !page.includes('/404')
    })
  ],
});
